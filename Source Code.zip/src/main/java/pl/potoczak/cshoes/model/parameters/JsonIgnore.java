package pl.potoczak.cshoes.model.parameters;

public @interface JsonIgnore {

}
