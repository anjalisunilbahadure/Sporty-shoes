package pl.potoczak.cshoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CShoesApplication {

    public static void main(String[] args) {
        SpringApplication.run(CShoesApplication.class, args);
    }

}
